package com.dandelion.mytasks;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addTask = findViewById(R.id.addTasksbtn);
        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToAddTask = new Intent(MainActivity.this, AddTask.class);
                startActivity(goToAddTask);
            }
        });

        Button allTasks = findViewById(R.id.allTasksbtn);
        allTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToAllTasks= new Intent(MainActivity.this, AllTasks.class);
                startActivity(goToAllTasks);
            }
        });

        Button task1 = findViewById(R.id.task1Btn);
        task1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskTitle= task1.getText().toString();
                Intent goToDetails = new Intent(MainActivity.this, TaskDetails.class);
                goToDetails.putExtra("title",taskTitle);
                startActivity(goToDetails);
            }
        });

//        Button task2 = findViewById(R.id.task2Btn);
//        task2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String taskTitle = task2.getText().toString();
//                Intent toDetails = new Intent(MainActivity.this, TaskDetails.class);
//                toDetails.putExtra("title", taskTitle);
//                startActivity(toDetails);
//            }
//        });
//
//        Button task3 = findViewById(R.id.task3Btn);
//        task3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String taskTitle = task3.getText().toString();
//                Intent toDetails = new Intent(MainActivity.this, TaskDetails.class);
//                toDetails.putExtra("title", taskTitle);
//                startActivity(toDetails);
//            }
//        });

        Button settings = findViewById(R.id.settingsBtn);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeToSettings = new Intent(MainActivity.this, Settings.class);
                startActivity(homeToSettings);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        String username = sharedPreferences.getString("username", "user");

        TextView usernameField = findViewById(R.id.myTasks);
        usernameField.setText(username+"'s Tasks");
    }
}