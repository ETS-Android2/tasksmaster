package com.dandelion.mytasks;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class TaskDetails extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_details2);

        Intent intent = getIntent();
        String title = intent.getExtras().getString("title");
        TextView titleText = findViewById(R.id.taskTitleView);
        titleText.setText(title);

    }
}