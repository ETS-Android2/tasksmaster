package com.dandelion.mytasks;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class AddTask extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        TextView totalTasks = findViewById(R.id.totalView);
        final int[] counter = {1};

        Button addTask = findViewById(R.id.addTaskBtn);
        addTask.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                totalTasks.setText("Total Tasks: "+ counter[0]++);
                Toast.makeText(getApplicationContext(), "Submit!", Toast.LENGTH_SHORT).show();
            }
        });

    }

}